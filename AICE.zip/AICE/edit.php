<?php
	include 'connection.php';
	$prod_id = $_GET['prod_id'];
?>
<!DOCTYPE html>
<html>
<head>
	<title> Update</title>
</head>
<link rel="stylesheet" type="text/css" href="css/style.css">
<style>
form{
	background-color: cadetblue;
	color: white;
	table-layout: auto;
	width:450px;
	height: 250px;
	padding-top: 20px;
	padding-bottom: 0px;
	font-size: 25px;
	text-align: center;
	border:1px solid black;
	border-collapse: collapse;	
}
body{
	height: 100%;
	background-image: url("img/bg.png");
}
h1{
	font-size: 50px;
	color: white;
	float: left;
}
.logo
{
   margin-top:5px;
}
.header
{
  padding:10px;
  color:#484848;
  font-size:20px;
  height:150px;
  margin-top: 10px;
  margin-bottom:0px;
}
span
{ 
	margin-top: 0px;
	font-size: 15px;
	color: white;
}
.right{
 float:right; 
 margin-top:-137px;
}
.button{
	background-color: white;
	color: black;
	padding: 0px;
	padding-bottom: 2px;
	padding-left: 5px;
	padding-right: 5px;
	font-size: 16px;
	border: 1px solid grey;
	text-decoration: none;

}
h3{
	font-size: 30px;
}
.left{
	float: left;
}
.sub{
	width:450px;
}
</style>
</head>
<body>
<header>
		<div class="main">
			<ul>
				<li><a href="product.php" style="background-color: grey; margin-right:10px;">PRODUCTS</a></li>	
				<li> <a href="home.php" style="background-color: grey;">LOGOUT</a></li>		
			</ul>
		</div>
		<div id="container">
		<div class="header" style="background-color: grey;">
			<div class="logo"><img src="img/logo.png" width="100" height="90" class="left">
			<h1>Aice Ice Cream</h1>
		</div>
		</div>
	</header>
<center>
	<br>
	<div style="background-color: cadetblue; color: white;" class="sub">
    <h3>Update Record</h3>
	</div>
	<div class="container">
		<?php
		$sqlDisplay = "SELECT * FROM tblproduct WHERE prod_id = '$prod_id'";
		$queryDisplay = mysqli_query($connect,$sqlDisplay);
		$row = mysqli_fetch_assoc($queryDisplay);

		?>
		<form action="edit.php?prod_id=<?=$row['prod_id']?>" method="POST">
		<label>Product ID</label>&emsp;&emsp;&emsp;
		<input type="text" placeholder="Enter Product ID" name="prod_id" value="<?=$row['prod_id']?>">
		<br>
		<label>Flavor</label>&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;&nbsp;
		<input type="text" placeholder="Enter Flavor" name="prod_name" value="<?=$row['prod_name']?>" >
		<br>
		<label>Price</label>&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;
		<input type="text" placeholder="Enter Price" name="prod_price" value="<?=$row['prod_price']?>">
		<br>
		<label>Quantity</label>&emsp;&emsp;&emsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<input type="text" placeholder="Enter Quantity" name="prod_quantity" value="<?=$row['prod_quantity']?>" >
		<br>
		<br>
		<br>
		<br>
		<button type="submit" name="btnUpdate" class="btn btn-success mt-3">Update</button>
		<a href="process.php" class="button"> Add Product</a>
		<a href="product.php" class="button"> Records</a>
			

		</form>

		<?php
		//Post Method
		 if(isset($_POST['btnUpdate'])){
			//initialization
			$prod_id = $_POST['prod_id'];
			$prod_name = $_POST['prod_name'];
			$prod_price = $_POST['prod_price'];
			$prod_quantity = $_POST['prod_quantity'];

		$sqlUpdate = "UPDATE tblproduct set prod_id = '$prod_id', prod_name = '$prod_name', prod_price = '$prod_price', prod_quantity = '$prod_quantity' WHERE prod_id = '$prod_id' ";
		$query = mysqli_query($connect,$sqlUpdate);
		if ($query == TRUE) {
			echo "Record Updated";
		}else{
			echo "Record Not Updated";
		}
	}
		?>

</div>
	</div>
</center>
<br><br><br><br><br><br>
<footer>
	<center>
		MADALE 2021

		
	</center>
</footer>
</body>
</html>
