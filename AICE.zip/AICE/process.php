<!DOCTYPE html>
<html>
<head>
<title>Aice Ice Cream</title>
<link rel="icon" href="img/logo.png" type="image">
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<style>
table{

	background-color: cadetblue;
	color: white;
	table-layout: auto;
	width:450px;
	height: 250px;
	padding-top: 20px;
	padding-bottom: 0px;
	font-size: 25px;
	text-align: center;
	border:1px solid black;
	border-collapse: collapse;	
}
body{
	height: 100%;
	background-image: url("img/bg.png");
}
h1{
	font-size: 50px;
	color: white;
	float: left;
}
b{
	font-size: 30px;
}
.button{
	background-color: white;
	color: black;
	padding: 0px;
	padding-bottom: 2px;
	padding-left: 5px;
	padding-right: 5px;
	font-size: 16px;
	border: 1px solid grey;
	text-decoration: none;

}
.logo
{
   margin-top:5px;
}

.header
{
  padding:10px;
  color:#484848;
  font-size:20px;
  height:150px;
  margin-top: 10px;
  margin-bottom:0px;
}
span
{ 
	margin-top: 0px;
	font-size: 15px;
	color: white;
}
.right{
 float:right; 
 margin-top:-137px;
}
.left{
float: left;
}

.sub{
	width:450px;
}
</style>
</head>

<body>
<header>
		<div class="main">
			<ul>
				<li><a href="home.php" style="background-color: grey; margin-right:10px;"> LOGOUT</a></li>	
			</ul>
		</div>
		<div id="container">
		<div class="header" style="background-color: grey;">
			<div class="logo"><img src="img/logo.png" width="100" height="90" class="left">
			<h1>Aice Ice Cream</h1>
		</div>
		</div>
	</header>
<center>
    <br>
	<div style="background-color: cadetblue; color: white;" class="sub">
    <b>Add Products</b>
	</div>
		<br><br>
			<table>
				<form action="process.php" method="POST">
		<tr>
			<td>
				Product ID
			</td>
			<td>
				<input type="text" name="prod_id" placeholder="Product ID">
			</td>
		</tr>
		<tr>
			<td>
				Flavor
			</td>
			<td>
				<input type="text" name="prod_name" placeholder="Flavor">
			</td>
		</tr>
		<tr>
			<td>
				Price
			</td>
			<td>
				<input type="text" name="prod_price" placeholder="Price">
			</td>
		</tr>
		<tr>
			<td>
				Quantity
			</td>
			<td>
				<input type="text" name="prod_quantity" placeholder="Quantity">
			</td>
		</tr>
		
		<tr>
			<td>
				
			</td>
	
			<td>
				<input type="submit" value="Save" class="btn btn-success" name="btnSave">
				&nbsp;<a href="product.php" class="button">Records</a>
			</td>
		</tr>
<?php
			$servername = "localhost";
			$username = "root";
			$password = "";
			$databasename = "dbproduct";

		$connect = mysqli_connect($servername,$username,$password,$databasename);

					if (isset($_POST['btnSave'])) {
						$prod_id = $_POST['prod_id'];
						$prod_name = $_POST['prod_name'];
						$prod_price = $_POST['prod_price'];
						$prod_quantity = $_POST['prod_quantity'];
						

		$insert = "INSERT INTO tblproduct(prod_id,prod_name,prod_price,prod_quantity)VALUES('$prod_id','$prod_name','$prod_price','$prod_quantity')";
		$query = mysqli_query($connect,$insert);

					if ($query == TRUE) {
						echo "Record Added";
					}
					else{
						echo "Record Not Added";
					}

					}

		?>

</table>
		</form>
</center>
<br><br><br><br><br><br><br><br>
<footer>
	<center>
		MADALE 2021
	</center>
</footer>

</body>
</html>
