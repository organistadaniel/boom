<?php
	//initialization
	$servername = "localhost";
	$username = "root";
	$password = "";
	$databasename  = "dbproduct";

	//connection php to mysql
	// procedural method
	$connect = mysqli_connect($servername,$username,$password,$databasename);

	/*if (!$connect) {
		echo "Not Connected";
	}else{
		echo "Connected";
	}*/
	//object oriented
	//->
	//insert record
	//query for Insertion
	/*$sqlInsert = "INSERT INTO user(firstname,lastname,course,gender)VALUES('John Maverick','Veloria','BSIT','Female')";
	$query = mysqli_query($connect,$sqlInsert);
	if($query == TRUE){
		echo "Record Added";
	}else{
		echo "Record not Added";
	}*/

?>
