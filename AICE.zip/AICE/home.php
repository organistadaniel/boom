<!DOCTYPE html>
<html>
<head>
<title>Aice Ice Cream</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="icon" href="img/logo.png" type="image">	
<style>
.title{
	color: black;
	table-layout: auto;
	width:1000px;
	height: 255px;
	padding-top: 5px;
	padding-bottom: 0px;
	font-size: 16px;
	text-align: center;
	border:2px solid white;
	border-collapse: collapse;
	border-radius: 1px;
}
body{
	background-color: #FFEA97;
	background-size: cover;
	background-position: center;
	height: 100%;
}
ul{
	float: right;
	list-style-type: none;
	margin-top: 25px;
}
ul li{
	display: inline-block;
}
ul li a{
	text-decoration: none;
	color: white;
	padding: 5px 20px;
	border: 1px solid white;
	transition: 0.6s ease;
}
ul li a:hover{
	background-color: white;
	color: black;
}
 footer{
	font-size: 17px;
	font-weight: bold;
	text-align: center;
	background: grey;
	color: white;
	font-family: Tahoma;
}

h1{
	font-size: 50px;
	float: left;
}
.right{
 float:right; 
 margin-top:-137px;
}

.register{
	background-color: #F8B430;
	table-layout: auto;
	width:450px;
	height: 240px;
	padding-top: 20px;
	padding-bottom: 0px;
	font-size: 25px;
	text-align: center;
	border:1px solid black;
	border-collapse: collapse;	
}
.button a{
	background-color: white;
	color: black;
	padding: 0px;
	padding-bottom: 2px;
	padding-left: 5px;
	padding-right: 5px;
	font-size: 16px;
	border: 1px solid black;
	text-decoration: none;

}

span
{ 
	margin-top: 0px;
	font-size: 15px;
	color: white;
}

.left
{
	float: left;
	margin-bottom: 5px;
	margin-left: 20px;
}

.flex{
display: inline-flex;
}
</style>
</head>

<body>
<header>
	<form style="background-color: grey; height: 80px; padding-top: 10px;" 
        action="home.php" method="POST">
		<div style="padding: 10px; width: 350px; display: inline-flex; ">
		</div><br>
		<div align="right" style="margin-left: 900px; display: inline; width: 700px;">
			<div class="flex">
				<div><input style="width: 180px; margin: 5px; font-size: 15px;" type="text" name="usname" placeholder="username/email" required></div>		
				<div><input style="width: 130px; margin: 5px; font-size: 15px;" type="password" name="pass" placeholder="password" required></div>
			</div>
			<input style="margin: 5px; font-size: 15;" type="submit" name="login" value="Login">
		</div>
	</form>         
	</header>
		<center>
		<div class="title">
			<img src="img/aice.png" width="990" height="250">
		</div>
		</center>
<br>
<center>  
	<form method="POST" action="home.php" class="register">
		<b>REGISTER</b>
		<br><br>

			First Name:&emsp;<input type="text" name="fname" placeholder="First name"> 
			<br>															
			Last Name:&emsp;<input type="text" name="lname" placeholder="Last name">
			<br>
			Username:&emsp;&nbsp;<input type="text" name="uname" placeholder="Username">
			<br>
			Password:&emsp;&nbsp;&nbsp;<input type="text" name="password" placeholder="Password">
			<br><br>

			<div class="button">
			<input type="Submit" class="btn btn-success" name="register" value="Register" >				
		</div>
	</form>	
</center>
<?php
		$servername="localhost";
		$username="root";
		$password="";
		$databasename="dbregister";

		$connect= mysqli_connect($servername, $username, $password, $databasename);

		if (isset($_POST ['login'])){

		$u = $_POST['usname'];
		$p = $_POST['pass'];

			$query= "SELECT * FROM tblregister WHERE uname = '$u' AND password = '$p'";
			$result = mysqli_query($connect, $query);
			$count= mysqli_num_rows($result);

			if ($count>0)
			{
				header("location: product.php");
			}
			else {
				echo "<h3><b>Username/Password is Incorrect</b></h3>";
			}
		}
	?>

	<?php
		$servername="localhost";
		$username="root";
		$password="";
		$databasename="dbregister";

		$connect= mysqli_connect($servername, $username, $password, $databasename);
	?>
	<?php
		if (isset($_POST ['register'])){
			$fname = $_POST['fname'];
			$lname = $_POST['lname'];
			$username = $_POST['uname'];
			$password = $_POST['password'];
			
			$insert = "INSERT INTO tblregister (fname,lname,uname,password) VALUES ('$fname','$lname','$username', '$password')";

			$query = mysqli_query($connect,$insert);
			if ($query==True )
			{
					echo "<center><h3>Record added</h3>";
				}
				else {
					echo "<b>Record not added </b>";
				}
			}	
		?>
<br>
<footer>
	<center>
		MADALE 2021
	</center>
</footer>
</body>
</html>


