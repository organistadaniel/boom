<?php
	include 'connection.php';
	$prod_id = $_GET['prod_id'];
	//echo "$id";

	//delete a single record
	$sqlDelete = "DELETE FROM tblproduct WHERE prod_id = '$prod_id'";
	$delete = mysqli_query($connect,$sqlDelete);
	if ($delete == TRUE) {
		header("location:product.php");
	}else{
		echo "Record Not Deleted";
	}

?>